# keylogger
This python script logs the keys you press and sends it to an email.
